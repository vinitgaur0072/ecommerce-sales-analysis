-- ==========================================
-- PRIMEOR SOLUTIONS - E-COMMERCE SQL ANALYSIS
-- ==========================================


-- TASK 1: TOP 10 PROFITABLE PRODUCTS

SELECT
    product_name,
    SUM(profit) AS total_profit
FROM ecommerce
GROUP BY product_name
ORDER BY total_profit DESC
LIMIT 10;


-- TASK 2: TOP 10 CUSTOMERS BY SALES

SELECT
    customer_name,
    SUM(sales) AS total_sales
FROM ecommerce
WHERE customer_name IS NOT NULL
GROUP BY customer_name
ORDER BY total_sales DESC
LIMIT 10;


-- TASK 3: REGION-WISE TOTAL SALES

SELECT
    region,
    SUM(sales) AS total_sales
FROM ecommerce
GROUP BY region
ORDER BY total_sales DESC;


-- TASK 4: CATEGORY-WISE AVERAGE PROFIT

SELECT
    category,
    ROUND(AVG(profit), 2) AS average_profit
FROM ecommerce
GROUP BY category
ORDER BY average_profit DESC;


-- TASK 5: HIGHEST DISCOUNT CATEGORY

SELECT
    category,
    ROUND(AVG(discount) * 100, 2) AS average_discount_percentage
FROM ecommerce
GROUP BY category
ORDER BY average_discount_percentage DESC
LIMIT 1;

-- TASK 6: ORDERS WITH NEGATIVE PROFIT

SELECT
    order_id,
    order_date,
    customer_name,
    product_name,
    sales,
    profit
FROM ecommerce
WHERE profit < 0
ORDER BY profit ASC;


-- TASK 7: MONTHLY SALES TREND

SELECT
    DATE_TRUNC('month', order_date)::DATE AS sales_month,
    ROUND(SUM(sales), 2) AS total_sales
FROM ecommerce
GROUP BY DATE_TRUNC('month', order_date)
ORDER BY sales_month;


-- TASK 8: MARKET-WISE REVENUE ANALYSIS

SELECT
    market,
    ROUND(SUM(sales), 2) AS total_revenue
FROM ecommerce
GROUP BY market
ORDER BY total_revenue DESC;


-- TASK 9: TOP-PERFORMING SUB-CATEGORIES

SELECT
    sub_category,
    ROUND(SUM(sales), 2) AS total_sales,
    ROUND(SUM(profit), 2) AS total_profit
FROM ecommerce
GROUP BY sub_category
ORDER BY total_profit DESC
LIMIT 10;


-- TASK 10: SHIP MODE USAGE ANALYSIS

SELECT
    ship_mode,
    COUNT(DISTINCT order_id) AS total_orders,
    ROUND(
        COUNT(DISTINCT order_id) * 100.0 /
        NULLIF((SELECT COUNT(DISTINCT order_id)
                FROM ecommerce), 0),
        2
    ) AS usage_percentage
FROM ecommerce
GROUP BY ship_mode
ORDER BY total_orders DESC;